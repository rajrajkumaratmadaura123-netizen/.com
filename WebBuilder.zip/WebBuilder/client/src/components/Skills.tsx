import { Calculator, Award, Users, Brain, MessageSquare } from "lucide-react";

export default function Skills() {
  const skills = [
    { name: "Excel Advanced Functions", percentage: 95 },
    { name: "Power BI Development", percentage: 90 },
    { name: "Data Visualization", percentage: 88 },
    { name: "AI Integration", percentage: 85 },
    { name: "Statistical Analysis", percentage: 82 },
    { name: "Business Insights Generation", percentage: 88 },
    { name: "Critical Thinking", percentage: 92 },
    { name: "Problem Solving", percentage: 90 },
    { name: "Data Interpretation", percentage: 87 },
    { name: "Business Communications", percentage: 85 }
  ];

  const additionalSkills = [
    "Team Collaboration", "Leadership", "Communication", 
    "Tableau (Beginner)", "Basic Python for Data", "Report Automation",
    "Remote Collaboration", "Pivot Tables", "Data Cleaning",
    "Microsoft PowerPoint", "Microsoft Word"
  ];

  const excelFunctions = [
    "VLOOKUP", "HLOOKUP", "XLOOKUP", "INDEX & MATCH",
    "SUMIF/COUNTIF", "Pivot Charts", "OFFSET", "Date Functions"
  ];

  const certifications = [
    "Microsoft Excel Expert Certification",
    "Power BI Data Analyst Associate", 
    "Google Data Analytics Professional"
  ];

  return (
    <section id="skills" className="py-20 bg-slate-50" data-testid="skills-section">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16 animate-fade-in-up">
          <h2 className="text-4xl font-bold text-gray-900 mb-4" data-testid="skills-title">Technical Skills</h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto" data-testid="skills-description">
            Mastery of essential data analytics tools and advanced techniques
          </p>
        </div>

        <div className="grid lg:grid-cols-2 gap-12 mb-16">
          <div>
            <h3 className="text-2xl font-semibold text-gray-900 mb-8" data-testid="core-competencies-title">Core Competencies</h3>
            {skills.map((skill, index) => (
              <div key={index} className="mb-6" data-testid={`skill-${index}`}>
                <div className="flex justify-between items-center mb-2">
                  <span className="font-medium text-gray-900" data-testid={`skill-name-${index}`}>
                    {skill.name}
                  </span>
                  <span className="text-primary font-semibold" data-testid={`skill-percentage-${index}`}>
                    {skill.percentage}%
                  </span>
                </div>
                <div className="w-full bg-gray-200 rounded-full h-2">
                  <div 
                    className="bg-primary h-2 rounded-full transition-all duration-1000 ease-out"
                    style={{ width: `${skill.percentage}%` }}
                    data-testid={`skill-bar-${index}`}
                  />
                </div>
              </div>
            ))}
          </div>

          <div>
            <h3 className="text-2xl font-semibold text-gray-900 mb-8" data-testid="excel-functions-title">Excel Functions Expertise</h3>
            <div className="grid grid-cols-2 gap-4">
              {excelFunctions.map((func, index) => (
                <div 
                  key={index}
                  className="bg-white p-4 rounded-lg shadow-sm border border-gray-100"
                  data-testid={`excel-function-${index}`}
                >
                  <div className="flex items-center">
                    <Calculator className="text-primary mr-2 h-4 w-4" />
                    <span className="font-medium text-gray-900">{func}</span>
                  </div>
                </div>
              ))}
            </div>

            <div className="mt-8">
              <h4 className="text-lg font-semibold text-gray-900 mb-4" data-testid="certifications-title">Certifications</h4>
              <div className="space-y-3">
                {certifications.map((cert, index) => (
                  <div 
                    key={index}
                    className="flex items-center bg-white p-4 rounded-lg shadow-sm"
                    data-testid={`certification-${index}`}
                  >
                    <Award className="text-primary mr-3 h-5 w-5" />
                    <span className="text-gray-900">{cert}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* Additional Skills Section */}
        <div className="mt-16">
          <h3 className="text-2xl font-semibold text-gray-900 mb-8 text-center" data-testid="additional-skills-title">Additional Skills & Tools</h3>
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
            {additionalSkills.map((skill, index) => (
              <div 
                key={index}
                className="bg-white p-4 rounded-lg shadow-sm border border-gray-100 hover:shadow-md transition-shadow"
                data-testid={`additional-skill-${index}`}
              >
                <div className="flex items-center justify-center text-center">
                  {skill.includes('Team') || skill.includes('Leadership') || skill.includes('Collaboration') ? (
                    <Users className="text-primary mr-2 h-4 w-4 flex-shrink-0" />
                  ) : skill.includes('Communication') ? (
                    <MessageSquare className="text-primary mr-2 h-4 w-4 flex-shrink-0" />
                  ) : (
                    <Brain className="text-primary mr-2 h-4 w-4 flex-shrink-0" />
                  )}
                  <span className="font-medium text-gray-900 text-sm">{skill}</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
