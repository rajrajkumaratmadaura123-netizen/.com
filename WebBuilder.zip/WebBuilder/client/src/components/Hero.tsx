import { Button } from "@/components/ui/button";
import { Star, TrendingUp } from "lucide-react";

export default function Hero() {
  const scrollToSection = (sectionId: string) => {
    const element = document.getElementById(sectionId);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <section id="hero" className="pt-20 pb-16 bg-gradient-to-br from-blue-50 to-white" data-testid="hero-section">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          <div className="lg:pr-8 animate-fade-in-up">
            <h1 className="text-5xl lg:text-6xl font-bold text-gray-900 mb-6 leading-tight" data-testid="hero-title">
              Data Analytics 
              <span className="text-primary"> Expert</span>
            </h1>
            <p className="text-xl text-gray-600 mb-8 leading-relaxed" data-testid="hero-description">
              Transforming raw data into actionable insights with Excel mastery, Power BI dashboards, and AI integration. Helping businesses make data-driven decisions with precision and clarity.
            </p>
            <div className="flex flex-col sm:flex-row gap-4">
              <Button 
                onClick={() => scrollToSection('contact')}
                className="bg-primary hover:bg-secondary text-white px-8 py-4 rounded-lg font-semibold transition-all transform hover:scale-105 shadow-lg"
                data-testid="button-start-project"
              >
                Start Your Project
              </Button>
              <Button 
                variant="outline"
                onClick={() => scrollToSection('portfolio')}
                className="border-2 border-primary text-primary hover:bg-primary hover:text-white px-8 py-4 rounded-lg font-semibold transition-all"
                data-testid="button-view-work"
              >
                View My Work
              </Button>
            </div>
            <div className="flex items-center mt-8 space-x-6">
              <div className="flex items-center" data-testid="rating-display">
                <Star className="h-5 w-5 text-yellow-400 mr-1" />
                <span className="text-gray-600">4.9/5 Client Rating</span>
              </div>
              <div className="flex items-center" data-testid="project-count">
                <TrendingUp className="h-5 w-5 text-primary mr-2" />
                <span className="text-gray-600">50+ Projects Completed</span>
              </div>
            </div>
          </div>
          <div className="lg:pl-8">
            <img 
              src="https://images.unsplash.com/photo-1551434678-e076c223a692?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=800&h=600" 
              alt="Professional data analytics workspace" 
              className="rounded-2xl shadow-2xl w-full h-auto transform hover:scale-105 transition-transform duration-300"
              data-testid="hero-image"
            />
          </div>
        </div>
      </div>
    </section>
  );
}
