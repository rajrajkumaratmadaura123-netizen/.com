import { useQuery } from "@tanstack/react-query";
import { Star } from "lucide-react";
import type { Testimonial } from "@shared/schema";

export default function Testimonials() {
  const { data: testimonials, isLoading } = useQuery<Testimonial[]>({
    queryKey: ["/api/testimonials"],
  });

  if (isLoading) {
    return (
      <section className="py-20 bg-white" data-testid="testimonials-loading">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <div className="animate-pulse">Loading testimonials...</div>
          </div>
        </div>
      </section>
    );
  }

  return (
    <section className="py-20 bg-white" data-testid="testimonials-section">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16 animate-fade-in-up">
          <h2 className="text-4xl font-bold text-gray-900 mb-4" data-testid="testimonials-title">Client Testimonials</h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto" data-testid="testimonials-description">
            What my clients say about working with me
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {testimonials?.map((testimonial, index) => (
            <div 
              key={testimonial.id}
              className="bg-slate-50 p-8 rounded-xl"
              data-testid={`testimonial-${index}`}
            >
              <div className="flex items-center mb-4" data-testid={`testimonial-rating-${index}`}>
                <div className="flex text-yellow-400">
                  {[1, 2, 3, 4, 5].map((star) => (
                    <Star key={star} className="h-5 w-5 fill-current" />
                  ))}
                </div>
              </div>
              <p 
                className="text-gray-600 mb-6 italic"
                data-testid={`testimonial-content-${index}`}
              >
                "{testimonial.content}"
              </p>
              <div className="flex items-center">
                <div className="w-12 h-12 bg-primary rounded-full flex items-center justify-center text-white font-semibold mr-4">
                  <span data-testid={`testimonial-initials-${index}`}>{testimonial.initials}</span>
                </div>
                <div>
                  <div 
                    className="font-semibold text-gray-900"
                    data-testid={`testimonial-name-${index}`}
                  >
                    {testimonial.name}
                  </div>
                  <div 
                    className="text-gray-500 text-sm"
                    data-testid={`testimonial-title-${index}`}
                  >
                    {testimonial.title}
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
