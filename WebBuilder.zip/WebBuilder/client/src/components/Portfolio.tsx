import { ExternalLink } from "lucide-react";
import { Button } from "@/components/ui/button";

export default function Portfolio() {
  const portfolioItems = [
    {
      image: "https://images.unsplash.com/photo-1551288049-bebda4e38f71?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=800&h=600",
      title: "Sales Analytics Dashboard",
      description: "Interactive Power BI dashboard for real-time sales tracking and performance analysis",
      tags: ["Power BI", "Excel", "SQL"]
    },
    {
      image: "https://images.unsplash.com/photo-1460925895917-afdab827c52f?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=800&h=600",
      title: "Financial Reporting System",
      description: "Automated Excel-based financial reporting with advanced formulas and pivot analysis",
      tags: ["Excel VBA", "Automation", "Finance"]
    },
    {
      image: "https://images.unsplash.com/photo-1553028826-f4804a6dba3b?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=800&h=600",
      title: "AI Predictive Model",
      description: "Machine learning integration for customer behavior prediction and trend analysis",
      tags: ["Python", "AI/ML", "Analytics"]
    },
    {
      image: "https://images.unsplash.com/photo-1542744173-8e7e53415bb0?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=800&h=600",
      title: "Inventory Management System",
      description: "Comprehensive Excel solution for inventory tracking with automated alerts and reporting",
      tags: ["Excel", "Automation", "Logistics"]
    },
    {
      image: "https://images.unsplash.com/photo-1563986768609-322da13575f3?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=800&h=600",
      title: "HR Analytics Platform",
      description: "Employee performance tracking and HR metrics visualization using Power BI",
      tags: ["Power BI", "HR", "KPI"]
    },
    {
      image: "https://images.unsplash.com/photo-1590479773265-7464e5d48118?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=800&h=600",
      title: "Market Research Analysis",
      description: "Statistical analysis and trend identification for market research with advanced Excel modeling",
      tags: ["Excel", "Statistics", "Research"]
    }
  ];

  const tagColors: { [key: string]: string } = {
    "Power BI": "bg-blue-100 text-blue-800",
    "Excel": "bg-green-100 text-green-800",
    "SQL": "bg-purple-100 text-purple-800",
    "Excel VBA": "bg-green-100 text-green-800",
    "Automation": "bg-yellow-100 text-yellow-800",
    "Finance": "bg-red-100 text-red-800",
    "Python": "bg-purple-100 text-purple-800",
    "AI/ML": "bg-blue-100 text-blue-800",
    "Analytics": "bg-orange-100 text-orange-800",
    "Logistics": "bg-gray-100 text-gray-800",
    "HR": "bg-pink-100 text-pink-800",
    "KPI": "bg-indigo-100 text-indigo-800",
    "Statistics": "bg-teal-100 text-teal-800",
    "Research": "bg-cyan-100 text-cyan-800"
  };

  return (
    <section id="portfolio" className="py-20 bg-white" data-testid="portfolio-section">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16 animate-fade-in-up">
          <h2 className="text-4xl font-bold text-gray-900 mb-4" data-testid="portfolio-title">Portfolio</h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto" data-testid="portfolio-description">
            Showcasing successful data analytics projects and dashboard implementations
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {portfolioItems.map((item, index) => (
            <div 
              key={index}
              className="group relative bg-white rounded-xl shadow-lg overflow-hidden hover:shadow-2xl transition-all duration-300"
              data-testid={`portfolio-item-${index}`}
            >
              <img 
                src={item.image}
                alt={item.title}
                className="w-full h-48 object-cover group-hover:scale-110 transition-transform duration-300"
                data-testid={`portfolio-image-${index}`}
              />
              <div className="p-6">
                <h3 
                  className="text-xl font-semibold text-gray-900 mb-2"
                  data-testid={`portfolio-item-title-${index}`}
                >
                  {item.title}
                </h3>
                <p 
                  className="text-gray-600 mb-4"
                  data-testid={`portfolio-item-description-${index}`}
                >
                  {item.description}
                </p>
                <div className="flex flex-wrap gap-2 mb-4">
                  {item.tags.map((tag, tagIndex) => (
                    <span 
                      key={tagIndex}
                      className={`px-3 py-1 rounded-full text-xs font-medium ${tagColors[tag] || 'bg-gray-100 text-gray-800'}`}
                      data-testid={`portfolio-tag-${index}-${tagIndex}`}
                    >
                      {tag}
                    </span>
                  ))}
                </div>
                <Button 
                  variant="ghost"
                  className="text-primary font-semibold hover:text-secondary transition-colors p-0"
                  data-testid={`portfolio-view-project-${index}`}
                >
                  View Project <ExternalLink className="ml-1 h-4 w-4" />
                </Button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
