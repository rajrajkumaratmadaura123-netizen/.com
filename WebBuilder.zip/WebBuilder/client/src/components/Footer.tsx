import { Linkedin, Github, Instagram } from "lucide-react";

export default function Footer() {
  const scrollToSection = (sectionId: string) => {
    const element = document.getElementById(sectionId);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <footer className="bg-gray-900 text-white py-12" data-testid="footer">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid md:grid-cols-4 gap-8">
          <div className="col-span-2">
            <div className="text-2xl font-bold text-white mb-4" data-testid="footer-logo">Raj Kr. Pandit</div>
            <p className="text-gray-300 mb-6" data-testid="footer-description">
              Ambitious data analyst specializing in Excel automation, Power BI dashboards, and AI integration. Helping businesses make data-driven decisions with precision and expertise.
            </p>
            <div className="flex space-x-4" data-testid="footer-social-links">
              <a href="https://www.linkedin.com/in/raj-kumar-112469374" target="_blank" rel="noopener noreferrer" className="text-gray-400 hover:text-white transition-colors">
                <Linkedin className="h-6 w-6" />
              </a>
              <a href="https://github.com/rajrajkumaratmadaura123-netizen" target="_blank" rel="noopener noreferrer" className="text-gray-400 hover:text-white transition-colors">
                <Github className="h-6 w-6" />
              </a>
              <a href="https://www.instagram.com/rajkumarpanditt01?igsh=MWwzdGZwenlyZHoxbw==" target="_blank" rel="noopener noreferrer" className="text-gray-400 hover:text-white transition-colors">
                <Instagram className="h-6 w-6" />
              </a>
            </div>
          </div>
          <div>
            <h4 className="text-lg font-semibold mb-4" data-testid="footer-services-title">Services</h4>
            <ul className="space-y-2 text-gray-300">
              <li><a href="#" className="hover:text-white transition-colors" data-testid="footer-service-excel">Excel Automation</a></li>
              <li><a href="#" className="hover:text-white transition-colors" data-testid="footer-service-powerbi">Power BI Dashboards</a></li>
              <li><a href="#" className="hover:text-white transition-colors" data-testid="footer-service-ai">AI Integration</a></li>
              <li><a href="#" className="hover:text-white transition-colors" data-testid="footer-service-analysis">Data Analysis</a></li>
            </ul>
          </div>
          <div>
            <h4 className="text-lg font-semibold mb-4" data-testid="footer-links-title">Quick Links</h4>
            <ul className="space-y-2 text-gray-300">
              <li>
                <button 
                  onClick={() => scrollToSection('about')} 
                  className="hover:text-white transition-colors text-left"
                  data-testid="footer-link-about"
                >
                  About
                </button>
              </li>
              <li>
                <button 
                  onClick={() => scrollToSection('portfolio')} 
                  className="hover:text-white transition-colors text-left"
                  data-testid="footer-link-portfolio"
                >
                  Portfolio
                </button>
              </li>
              <li>
                <button 
                  onClick={() => scrollToSection('skills')} 
                  className="hover:text-white transition-colors text-left"
                  data-testid="footer-link-skills"
                >
                  Skills
                </button>
              </li>
              <li>
                <button 
                  onClick={() => scrollToSection('contact')} 
                  className="hover:text-white transition-colors text-left"
                  data-testid="footer-link-contact"
                >
                  Contact
                </button>
              </li>
            </ul>
          </div>
        </div>
        <div className="border-t border-gray-800 pt-8 mt-8 text-center text-gray-400" data-testid="footer-copyright">
          <p>&copy; 2024 Raj Kr. Pandit. All rights reserved. Built with precision and expertise.</p>
        </div>
      </div>
    </footer>
  );
}
