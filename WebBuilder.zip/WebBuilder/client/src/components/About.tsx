import { TrendingUp, Bot, Linkedin, Github, Instagram } from "lucide-react";

export default function About() {
  return (
    <section id="about" className="py-20 bg-white" data-testid="about-section">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid lg:grid-cols-2 gap-16 items-center">
          <div>
            <img 
              src="https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=800&h=600" 
              alt="Professional data analyst portrait" 
              className="rounded-2xl shadow-xl w-full h-auto"
              data-testid="about-image"
            />
          </div>
          <div className="animate-fade-in-up">
            <h2 className="text-4xl font-bold text-gray-900 mb-6" data-testid="about-title">About Me</h2>
            <p className="text-lg text-gray-600 mb-6 leading-relaxed" data-testid="about-description-1">
              I'm an ambitious and passionate Data Analyst with a B.Sc. degree and a strong foundation in Excel, AI tools, and data-driven decision-making. As a fresher, I bring relentless curiosity, a willingness to learn, and an "always-on" work ethic that sets me apart.
            </p>
            <p className="text-lg text-gray-600 mb-8 leading-relaxed" data-testid="about-description-2">
              I've completed certifications in Data Analytics, Power BI, and ChatGPT for Business, and I'm proficient at turning complex data into clear, actionable insights. My communication and leadership skills have helped me shine in academics, earning medals in music and public speaking. I specialize in Excel automation, Power BI dashboards, and AI integration to help businesses make better decisions.
            </p>
            
            <div className="grid sm:grid-cols-2 gap-6 mb-8">
              <div className="bg-blue-50 p-6 rounded-lg" data-testid="feature-analytics">
                <TrendingUp className="text-primary h-8 w-8 mb-3" />
                <h3 className="font-semibold text-gray-900 mb-2">Advanced Analytics</h3>
                <p className="text-gray-600 text-sm">Statistical modeling and predictive analysis</p>
              </div>
              <div className="bg-blue-50 p-6 rounded-lg" data-testid="feature-ai">
                <Bot className="text-primary h-8 w-8 mb-3" />
                <h3 className="font-semibold text-gray-900 mb-2">AI Integration</h3>
                <p className="text-gray-600 text-sm">Machine learning and automation solutions</p>
              </div>
            </div>

            <div className="flex items-center space-x-4" data-testid="social-links">
              <a href="https://www.linkedin.com/in/raj-kumar-112469374" target="_blank" rel="noopener noreferrer" className="text-primary hover:text-secondary transition-colors">
                <Linkedin className="h-6 w-6" />
              </a>
              <a href="https://github.com/rajrajkumaratmadaura123-netizen" target="_blank" rel="noopener noreferrer" className="text-primary hover:text-secondary transition-colors">
                <Github className="h-6 w-6" />
              </a>
              <a href="https://www.instagram.com/rajkumarpanditt01?igsh=MWwzdGZwenlyZHoxbw==" target="_blank" rel="noopener noreferrer" className="text-primary hover:text-secondary transition-colors">
                <Instagram className="h-6 w-6" />
              </a>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
