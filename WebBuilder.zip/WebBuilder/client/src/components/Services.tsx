import { FileSpreadsheet, BarChart3, Brain, ArrowRight, Check } from "lucide-react";
import { Button } from "@/components/ui/button";

export default function Services() {
  const services = [
    {
      icon: FileSpreadsheet,
      title: "Excel Automation",
      description: "Advanced formulas, macros, and VBA solutions to automate your spreadsheet workflows and increase productivity.",
      features: [
        "VLOOKUP/HLOOKUP/XLOOKUP",
        "Pivot Tables & Charts", 
        "VBA Macros"
      ]
    },
    {
      icon: BarChart3,
      title: "Power BI Dashboards",
      description: "Interactive visualizations and real-time dashboards that turn your data into compelling business insights.",
      features: [
        "Interactive Dashboards",
        "Data Modeling",
        "Real-time Updates"
      ]
    },
    {
      icon: Brain,
      title: "AI Integration", 
      description: "Leverage artificial intelligence to automate data analysis, prediction modeling, and intelligent insights.",
      features: [
        "Machine Learning Models",
        "Predictive Analytics",
        "Process Automation"
      ]
    }
  ];

  return (
    <section id="services" className="py-20 bg-slate-50" data-testid="services-section">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16 animate-fade-in-up">
          <h2 className="text-4xl font-bold text-gray-900 mb-4" data-testid="services-title">My Services</h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto" data-testid="services-description">
            Comprehensive data analytics solutions tailored to your business needs
          </p>
        </div>
        
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {services.map((service, index) => (
            <div 
              key={index}
              className="bg-white p-8 rounded-xl shadow-lg hover:shadow-xl transition-all duration-300 transform hover:-translate-y-2"
              data-testid={`service-card-${index}`}
            >
              <div className="bg-primary/10 w-16 h-16 rounded-lg flex items-center justify-center mb-6">
                <service.icon className="text-primary h-8 w-8" />
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-4" data-testid={`service-title-${index}`}>
                {service.title}
              </h3>
              <p className="text-gray-600 mb-6" data-testid={`service-description-${index}`}>
                {service.description}
              </p>
              <ul className="text-sm text-gray-500 space-y-2 mb-6">
                {service.features.map((feature, featureIndex) => (
                  <li 
                    key={featureIndex}
                    className="flex items-center"
                    data-testid={`service-feature-${index}-${featureIndex}`}
                  >
                    <Check className="h-4 w-4 text-primary mr-2" />
                    {feature}
                  </li>
                ))}
              </ul>
              <Button 
                variant="ghost"
                className="text-primary font-semibold hover:text-secondary transition-colors p-0"
                data-testid={`service-learn-more-${index}`}
              >
                Learn More <ArrowRight className="ml-1 h-4 w-4" />
              </Button>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
