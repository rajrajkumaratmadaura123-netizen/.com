# Overview

This is a professional portfolio website for Raj Kr. Pandit, a passionate and ambitious Data Analyst specializing in Excel automation, Power BI dashboards, and AI integration. The application showcases services, portfolio projects, skills, testimonials, and provides a contact form for potential clients. Built as a full-stack web application with a React frontend and Express backend.

# User Preferences

Preferred communication style: Simple, everyday language.

# System Architecture

## Frontend Architecture
- **Framework**: React 18 with TypeScript using Vite as the build tool
- **UI Components**: Radix UI primitives with shadcn/ui component library for consistent design system
- **Styling**: Tailwind CSS with CSS variables for theming and responsive design
- **Routing**: Wouter for lightweight client-side routing
- **State Management**: TanStack Query (React Query) for server state management and API data fetching
- **Form Handling**: React Hook Form with Zod validation for type-safe form management

## Backend Architecture
- **Framework**: Express.js with TypeScript running on Node.js
- **Database ORM**: Drizzle ORM with PostgreSQL dialect for type-safe database operations
- **Schema Validation**: Zod schemas shared between frontend and backend for consistent data validation
- **Storage Layer**: Abstracted storage interface with in-memory implementation for development
- **API Design**: RESTful API endpoints for testimonials and contact form submissions

## Data Storage
- **Database**: PostgreSQL configured through Drizzle ORM
- **Schema**: Two main entities - contacts and testimonials tables with UUID primary keys
- **Development Storage**: In-memory storage implementation with pre-seeded testimonial data
- **Connection**: Neon Database serverless driver for PostgreSQL connectivity

## Project Structure
- **Monorepo Layout**: Shared schema definitions between client and server
- **Client Directory**: React application with organized component structure
- **Server Directory**: Express API with route handlers and storage abstraction
- **Shared Directory**: Common TypeScript types and Zod schemas

## Development Features
- **Hot Reload**: Vite HMR integration with Express server in development
- **Type Safety**: Full TypeScript coverage across frontend and backend
- **Error Handling**: Custom error overlay and centralized error management
- **Build Process**: Separate build commands for client (Vite) and server (esbuild)

# External Dependencies

## Database Services
- **Neon Database**: Serverless PostgreSQL hosting with connection pooling
- **Drizzle Kit**: Database migration and schema management tools

## UI and Styling
- **Radix UI**: Accessible component primitives for complex UI patterns
- **Tailwind CSS**: Utility-first CSS framework with custom design tokens
- **Lucide React**: Icon library for consistent iconography
- **Google Fonts**: Inter font family for typography

## Development Tools
- **Vite**: Fast build tool with TypeScript support and plugin ecosystem
- **TanStack Query**: Server state management with caching and background updates
- **React Hook Form**: Performant form library with validation integration
- **Wouter**: Minimalist routing library for single-page applications

## Form and Validation
- **Zod**: TypeScript-first schema validation for forms and API data
- **React Hook Form Resolvers**: Integration layer for Zod validation with forms

## Additional Libraries
- **clsx/tailwind-merge**: Utility functions for conditional CSS classes
- **date-fns**: Modern date utility library for JavaScript/TypeScript
- **class-variance-authority**: Type-safe variant management for component styling