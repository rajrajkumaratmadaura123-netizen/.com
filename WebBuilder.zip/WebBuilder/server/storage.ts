import { type Contact, type InsertContact, type Testimonial, type InsertTestimonial } from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  // Contact methods
  createContact(contact: InsertContact): Promise<Contact>;
  getContacts(): Promise<Contact[]>;
  getContact(id: string): Promise<Contact | undefined>;
  
  // Testimonial methods
  createTestimonial(testimonial: InsertTestimonial): Promise<Testimonial>;
  getTestimonials(): Promise<Testimonial[]>;
  getTestimonial(id: string): Promise<Testimonial | undefined>;
}

export class MemStorage implements IStorage {
  private contacts: Map<string, Contact>;
  private testimonials: Map<string, Testimonial>;

  constructor() {
    this.contacts = new Map();
    this.testimonials = new Map();
    
    // Initialize with some testimonials
    this.initializeTestimonials();
  }

  private initializeTestimonials() {
    const initialTestimonials: InsertTestimonial[] = [
      {
        name: "John Smith",
        title: "Operations Manager",
        content: "The Excel automation solution saved our team 15 hours per week. The dashboard is exactly what we needed for our sales tracking.",
        initials: "JS",
        rating: "5"
      },
      {
        name: "Maria Rodriguez",
        title: "Data Manager", 
        content: "Outstanding Power BI dashboard that transformed how we view our data. Professional, responsive, and delivered on time.",
        initials: "MR",
        rating: "5"
      },
      {
        name: "David Lee",
        title: "Business Owner",
        content: "The AI integration for our inventory system was beyond our expectations. Truly innovative approach to data analysis.",
        initials: "DL",
        rating: "5"
      }
    ];

    initialTestimonials.forEach(testimonial => {
      this.createTestimonial(testimonial);
    });
  }

  async createContact(insertContact: InsertContact): Promise<Contact> {
    const id = randomUUID();
    const contact: Contact = {
      ...insertContact,
      id,
      createdAt: new Date()
    };
    this.contacts.set(id, contact);
    return contact;
  }

  async getContacts(): Promise<Contact[]> {
    return Array.from(this.contacts.values()).sort((a, b) => 
      new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
    );
  }

  async getContact(id: string): Promise<Contact | undefined> {
    return this.contacts.get(id);
  }

  async createTestimonial(insertTestimonial: InsertTestimonial): Promise<Testimonial> {
    const id = randomUUID();
    const testimonial: Testimonial = {
      ...insertTestimonial,
      id
    };
    this.testimonials.set(id, testimonial);
    return testimonial;
  }

  async getTestimonials(): Promise<Testimonial[]> {
    return Array.from(this.testimonials.values());
  }

  async getTestimonial(id: string): Promise<Testimonial | undefined> {
    return this.testimonials.get(id);
  }
}

export const storage = new MemStorage();
